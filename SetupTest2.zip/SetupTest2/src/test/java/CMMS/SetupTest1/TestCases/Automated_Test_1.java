package  CMMS.SetupTest1.TestCases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

//import org.openqa.selenium.chrome.ChromeDriver;
//import java.io.File;
import java.time.Duration;
//import org.openqa.selenium.By;
//import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
//import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import CMMS.SetupTest1.PageObjects.PO_Common;
import CMMS.SetupTest1.TestCases.Utils.BrowserManager;

public class Automated_Test_1
{
	@Test
	@Parameters ({"browser", "url", "username", "password"})
	public void Automated_Test_Script_1(String browser, String url, String username, String password) throws InterruptedException {
		
		// Creates instance of driver based on specified browser and url
		WebDriver driver = BrowserManager.getDriver(browser,url);
		// Initializing Page Object for PO_Common class using provided driver instance
		PO_Common obj = PageFactory.initElements(driver, PO_Common.class);

		try {
			// EXAMPLES ///////////////////////////////////////////
		
			// Log into CMMS Dev website
			//obj.Login_To_CMMS_Dev(driver, username, password);
		
			// Pause for 10 seconds
			//Thread.sleep(10000);
		
			// Take screenshot
			//obj.takeScreenshotWithTaskbar();	
			
		    ///////////////////////////////////////////////////////
			
			
			
			
			///////////// Start your test case below //////////////
			
			//Thread.sleep(2000);
			//obj.DynSignIn();
			Thread.sleep(5000);
			
			//driver.switchTo().frame(0);
			WebElement iframe = driver.findElement(By.className("designer-client-frame"));
			driver.switchTo().frame(iframe);
			
			Thread.sleep(2000);			
			obj.DynItems();
			
			Thread.sleep(1000);			
			driver.switchTo().activeElement();
			
			Thread.sleep(2000);
			obj.DynNewItems();
			
			Thread.sleep(1000);
			driver.switchTo().activeElement();
			
			Thread.sleep(2000);
			obj.DynNewItemsFillOut();
			
			Thread.sleep(1000);
			obj.takeScreenshotWithTaskbar();
			
			//Thread.sleep(3000);
			//driver.switchTo().defaultContent();
			//driver.switchTo().frame(iframe);
			//driver.switchTo().activeElement();
			
			Thread.sleep(2000);
			obj.DynVendors();
			
			Thread.sleep(2000);
			obj.DynNewVendors();
			
			Thread.sleep(2000);
			driver.switchTo().activeElement();
			
			Thread.sleep(2000);
			obj.DynNewVendorsFillOut();
			
			Thread.sleep(1000);
			obj.takeScreenshotWithTaskbar();
			
			Thread.sleep(2000);
			obj.DynPurchaseOrders();
			
			Thread.sleep(2000);
			obj.DynNewPurchaseOrders();
			
			Thread.sleep(2000);
			obj.DynNewPurchaseOrdersFillOut();
			
			Thread.sleep(2000);
			obj.takeScreenshotWithTaskbar();
			
		} catch (PO_Common.stepFailure e) {
			driver.quit();
			Assert.fail("Test failed due to step error.");
		}
		
		
		//This timeout is used to specify the time the driver should wait while 
		//searching for an element if it is not immediately present.
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.close();
	

	}

}

