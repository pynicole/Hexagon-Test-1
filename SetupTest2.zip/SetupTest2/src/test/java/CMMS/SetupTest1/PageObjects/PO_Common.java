package CMMS.SetupTest1.PageObjects;

import java.time.Duration;
import java.awt.AWTException;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;

import javax.imageio.ImageIO;

import java.text.SimpleDateFormat;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import junit.framework.Assert;

//Define the class PO_Common. It represents a common base class for Page Objects.
public class PO_Common 
{
		// Declare a member variable "driver" of type WebDriver. It will hold the web driver instance used for automation.
		WebDriver driver;
		
		// Define a constructor for the PO_Common class. It takes a WebDriver object as a parameter.
		public PO_Common(WebDriver driver) {
			// Assign the provided WebDriver instance to the member variable "driver".
			this.driver = driver;
		}	
		
		// Declare a private static member variable "timestamp" of type String.
		private static String timestamp;
		
		
	    public class stepFailure extends RuntimeException {
	        public stepFailure(String message) {
	            super(message);
	        }
	    }
		
		
		

		
		
//----- PAGE OBJECTS -------------------------------------------------------------------------------------//
//-- This is where you define the specific button, field, or section on the webpage that you want to -----//
//-- interact with. Ideally you want to section them to what type of object and in alphabetical order ----//
//-- so you can find them easily. Below is an example on how to define an object. ------------------------//
//--------------------------------------------------------------------------------------------------------//
// Put a comment here about what the object is and on what specific page                                  //
// @FindBy(put what html tag you want to reference: should be id/name/or xpath (xpath most preferred)     //
// private WebElement insertNameOfObjectHere;                                                             //
//--------------------------------------------------------------------------------------------------------//

	    
//****** Dynamics website section ******//
	    
	    //Dynamics: Sign in button
	  	@FindBy(id="hero-basic_access-your-dynamics-365-business-central-account_CTA-1")
	  	private WebElement DynSignInButton;	
	  	
	    //Dynamics: Items button
	  	@FindBy(xpath="//*[@id=\"commandBarItemButton222\"]")
	  	private WebElement DynItemsButton;	

	  	//Dynamics: New button on Items page
	    @FindBy(xpath="/html/body/div[2]/div[3]/form/div/div[2]/div[3]/div/div[2]/div/div[1]/div[2]/div[3]/div/div/div/div[1]/div/div/div/div[1]/div/div/div/div/span/button[1]")
	  	private WebElement DynNewButtonOnItems;
	    
	    //Dynamics: Description on new items page
	    @FindBy(xpath="/html/body/div[2]/div[4]/form/main/div[2]/div[6]/div[2]/div[2]/div[2]/div/div[1]/div[2]/div/div/div[2]/div/input")
	    private WebElement DynDescOnItems;

	    //Dynamics: Base unit of measurement on new items page
	    @FindBy(xpath="/html/body/div[2]/div[4]/form/main/div[2]/div[6]/div[2]/div[2]/div[2]/div/div[1]/div[2]/div/div/div[7]/div/input")
	    private WebElement DynBaseUnitOnItems;	  
	    
	    //Dynamics: Base unit of measurement GR on new items page
	    @FindBy(xpath="/html/body/div[2]/div[5]/form/div[2]/div/div[1]/div/div/div[2]/table/tbody/tr[5]/td[2]/a")
	    private WebElement DynBaseUnitGROnItems;
	    
	    //Dynamics: Base unit of measurement GR on new items page
	    @FindBy(xpath="/html/body/div[2]/div[4]/form/main/div[2]/div[6]/div[2]/div[2]/div[2]/div/div[3]/div[1]/span[1]/span")
	    private WebElement DynCostsTabOnItems;
	    
	    //Dynamics: General posting group on new items page
	    @FindBy(xpath="/html/body/div[2]/div[4]/form/main/div[2]/div[6]/div[2]/div[2]/div[2]/div/div[3]/div[2]/div/div/div[2]/div[2]/div[1]/div/input")
	    private WebElement DynGPostGroupOnItems;	
	    
	    //Dynamics: Inventory posting group on new items page
	    @FindBy(xpath="/html/body/div[2]/div[4]/form/main/div[2]/div[6]/div[2]/div[2]/div[2]/div/div[3]/div[2]/div/div/div[2]/div[2]/div[4]/div/input")
	    private WebElement DynIPostGroupOnItems;
	    
	    //Dynamics: Back arrow button on new items page
	    @FindBy(xpath="/html/body/div[2]/div[4]/form/main/div[2]/div[2]/div/div/div[1]/span/button/span")
	    private WebElement DynBackOnItems;
	    
	    //Dynamics: Purchasing button
	    @FindBy(xpath="/html/body/div[2]/div[3]/form/div/div[2]/div[2]/div/div/nav/div[1]/div/div[2]/div/div/div/div[1]/div/div/div/div/div[6]/div/div/a/span/div[2]/span/span")
	    private WebElement DynPurchasing;
	    
	    //Dynamics: Vendors button under Purchasing
	    @FindBy(xpath="/html/body/div[2]/div[3]/form/div/div[2]/div[2]/div/div/nav/div[2]/div[1]/div/div/div/div[2]/div/div/div/div[1]/div/div/div/div/div/div/div[2]/div/div[1]/div[1]/div/div/button")
	    private WebElement DynVendors;
	    
	    //Dynamics: New button on Vendors page
	    @FindBy(xpath="/html/body/div[2]/div[4]/form/div/div[2]/div[3]/div/div[2]/div/div[1]/div[2]/div[3]/div/div/div/div[1]/div/div/div/div[1]/div/div/div/button/span/div/i")
	    private WebElement DynNewButtonOnVendors;
	    
	    //Dynamics: Name field on new Vendors page
	    @FindBy(xpath="/html/body/div[2]/div[5]/form/main/div[2]/div[6]/div[2]/div[2]/div[2]/div/div[1]/div[2]/div/div/div[2]/div/input")
	    private WebElement DynNameOnVendors;
	    
	    //Dynamics: Invoice tab on new Vendors page
	    @FindBy(xpath="/html/body/div[2]/div[5]/form/main/div[2]/div[6]/div[2]/div[2]/div[2]/div/div[3]/div[1]/span/span")
	    private WebElement DynInvoiceTabOnVendors;
	    
	    //Dynamics: Tax Area Code under Invoicing on new Vendors page
	    @FindBy(xpath="/html/body/div[2]/div[5]/form/main/div[2]/div[6]/div[2]/div[2]/div[2]/div/div[3]/div[2]/div/div/div[4]/div/a")
	    private WebElement DynTaxAreaOnVendors;
	    
	    //Dynamics: Tax Area Code 377 under Invoicing on new Vendors page
	    @FindBy(xpath="/html/body/div[2]/div[6]/form/div[2]/div/div[1]/div/div/div[2]/table/tbody/tr[2]/td[2]/a")
	    private WebElement DynTaxArea377OnVendors;
	    
	    //Dynamics: Gen. Bus. Posting Group under Invoicing on new Vendors page
	    @FindBy(xpath="/html/body/div[2]/div[5]/form/main/div[2]/div[6]/div[2]/div[2]/div[2]/div/div[3]/div[2]/div/div/div[7]/div[2]/div[1]/div/input")
	    private WebElement DynGenBusPostOnVendors;
	    
	    //Dynamics: Vendor Posting Group under Invoicing on new Vendors page
	    @FindBy(xpath="/html/body/div[2]/div[5]/form/main/div[2]/div[6]/div[2]/div[2]/div[2]/div/div[3]/div[2]/div/div/div[7]/div[2]/div[2]/div/input")
	    private WebElement DynVendorPostOnVendors;
	    
	    //Dynamics: Back arrow button on new Vendors page
	    @FindBy(xpath="/html/body/div[2]/div[5]/form/main/div[2]/div[2]/div/div/div[1]/span/button/span/i")
	    private WebElement DynBackOnVendors;
	    
	    //Dynamics: Purchasing button
	    @FindBy(xpath="/html/body/div[2]/div[4]/form/div/div[2]/div[2]/div/div/nav/div[1]/div/div[2]/div/div/div/div[1]/div/div/div/div/div[6]/div/div/a/span/div[2]/span/span")
	    private WebElement DynPurchasing2;
	    
	    //Dynamics: Purchase Orders on Purchasing tab
	    @FindBy(xpath="/html/body/div[2]/div[4]/form/div/div[2]/div[2]/div/div/nav/div[2]/div[1]/div/div/div/div[2]/div/div/div/div[1]/div/div/div/div/div/div/div[2]/div/div[2]/div[2]/div/div/button/span/span/span/span")
	    private WebElement DynPO;
	    
	    //Dynamics: New button on Purchasing Orders page
	    @FindBy(xpath="/html/body/div[2]/div[5]/form/div/div[2]/div[3]/div/div[2]/div/div[1]/div[2]/div[3]/div/div/div/div[1]/div/div/div/div[1]/div/div/div/button/span/div/i")
	    private WebElement DynNewOnPO;
	    
	    //Dynamics: Vendor Name field on Purchasing Order page
	    @FindBy(xpath="/html/body/div[2]/div[6]/form/main/div[2]/div[6]/div[2]/div[2]/div[2]/div/div[1]/div[2]/div/div/div[2]/div/input")
	    private WebElement DynVendorNameOnPO;
	    
	    //Dynamics: Vendor invoice number on Purchasing Order page
	    @FindBy(xpath="/html/body/div[2]/div[6]/form/main/div[2]/div[6]/div[2]/div[2]/div[2]/div/div[1]/div[2]/div/div/div[7]/div/input")
	    private WebElement DynVendorNumOnPO;
	    
	    //Dynamics: Item number field on Purchasing Order page
	    @FindBy(xpath="/html/body/div[2]/div[6]/form/main/div[2]/div[6]/div[2]/div[2]/div[2]/div/div[2]/div[3]/div/div[1]/div/div[2]/table/tbody/tr[1]/td[5]/input")
	    private WebElement DynItemFieldOnPO;
	    
	    //Dynamics: Item number field dropdown arrow on Purchasing Order page
	    @FindBy(xpath="/html/body/div[2]/div[7]/form/div[2]/div/div[1]/div/div/div[2]/table/tbody/tr[1]/td[2]")
	    private WebElement DynItemFieldSelectionOnPO;
	    
	    //Dynamics: Back arrow button on new Vendors page
	    @FindBy(xpath="/html/body/div[2]/div[7]/form/main/div/div[4]/button[1]/span")
	    private WebElement DynOkOnPO2;
	    
	    //Dynamics: Back arrow button on new Vendors page
	    @FindBy(xpath="/html/body/div[2]/div[7]/form/main/div/div[4]/button[1]/span")
	    private WebElement DynOkOnPO3;
	    
	    //Dynamics: Back arrow button on new Vendors page
	    @FindBy(xpath="/html/body/div[2]/div[7]/form/main/div/div[4]/button[1]/span")
	    private WebElement DynOkOnPO4;
	    
//****** Hexagon Dev website section ******//	
	    
	    //Hexagon: Username field
	    @FindBy(xpath="//*[@id=\"textfield-1034-inputEl\"]")
	    private WebElement HexUsername;
	    
	    //Hexagon: Password field
	    @FindBy(xpath="//*[@id=\"textfield-1035-inputEl\"]")
	    private WebElement HexPassword;
	    
	    //Hexagon: Login button
	    @FindBy(xpath="//*[@id=\"button-1037\"]")
	    private WebElement HexLoginButton;
	    
	    //Hexagon: Work tab
	    @FindBy(xpath="//*[@id=\"button-1044-btnWrap\"]")
	    private WebElement HexWorkTab;
	    
	    //Hexagon: Work Orders under Work tab
	    @FindBy(xpath="//*[@id=\"menuitem-1080-textEl\"]")
	    private WebElement HexWorkOrders;
	    
	    //Hexagon: Status filter
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[1]/div/div/div/div/div/div[3]/div/div/div[3]/div/div/div/div[1]/div/div/input")
	    private WebElement HexStatusFilter;
	    
	    //Hexagon: Run button on Work Orders screen
	    @FindBy(xpath="/html/body/div[1]/div/div/div/div/div[2]/div/div[1]/div/div/div/div/div[3]/div[1]/div/div/div/div/div/div[1]/div/div/a[3]/span/span/span[2]")
	    private WebElement HexRun;
	    
		
//****** CMMS Dev website section ******//		
		
	//--- BUTTONS/TABS ---//
		
		//CMMS Login Button
		@FindBy(id ="button-1036-btnInnerEl")
		private WebElement btn_LOGIN;	
		
		//CMMS the equipment tab
		@FindBy(xpath = "/html[@id='ext-element-6']/body[@id='ext-element-1']/div[@id='index-1026']/div[@id='index-1026-bodyWrap']/div[@id='index-1026-body']/div[@id='index-1026-innerCt']/div[@id='index-1026-targetEl']/div[@id='container-1027']/div[@id='container-1027-innerCt']/div[@id='container-1027-targetEl']/div[@id='mainmenubar-1032']/div[@id='mainmenubar-1032-innerCt']/div[@id='mainmenubar-1032-targetEl']/a[@id='button-1048']/span[@id='button-1048-btnWrap']/span[@id='button-1048-btnEl']/span[@id='button-1048-btnInnerEl']")
	    private WebElement EquipmentButton;
		
	    //CMMS Dev: Equipment dropdown menu
	    @FindBy(id="button-1048-btnInnerEl")
	  	private WebElement EquipmentMenuDropdown;
		
	  	//CMMS Dev: Search button on search bar
	  	@FindBy(id="uxpicktriggerfield-1297-trigger-trigger")
	  	private WebElement EquipmentSearchButton;

	  	//CMMS Dev: New Record button on Equipment page from Equipment dropdown
	  	@FindBy(xpath="//*[@id=\"button-1246-btnIconEl\"]")
	  	private WebElement NewRecordButton;
	  	
	  	//CMMS Dev: A new pop-up message when login in - OK button for this
	  	@FindBy(xpath="//*[@id=\"button-1013-btnInnerEl\"]")
	  	private WebElement OKButton;
	  	
	  	//CMMS Dev: Save Record button
	  	@FindBy(xpath="//*[@id=\"button-1245-btnIconEl\"]")
	  	private WebElement SaveRecordButton;
	  	
	  
	  	
	//--- USER FIELDS ---//
	  	
	  	//CMMS Dev: Field for Equipment Name
	  	@FindBy(xpath="//*[@id=\"textfield-1395-inputEl\"]")
	  	private WebElement EquipmentNameField;	 
	  	
	  	//CMMS Dev: Field for Equipment Type
	  	@FindBy(xpath="//*[@id=\"lovfield-1406-inputEl\"]")
	  	private WebElement EquipmentTypeField;
		
		//CMMS Testing Biogen, "password field"
		@FindBy(id="textfield-1035-inputEl")
		private WebElement PasswordField;
		
		//CMMS Testing Biogen, "User Id field"
		@FindBy(id ="textfield-1034-inputEl")
		private WebElement UserField;
		
		
	//--- SEARCH BARS / SEARCH BAR SELECTION ---//
		
	  	//CMMS Dev: Equipment search bar
	  	@FindBy(name="summarysearch")
	  	private WebElement EquipmentSearchBar;
	  	
	  	//CMMS Dev: First selection on search bar
	  	@FindBy(xpath = "//*[@id=\"ext-element-27\"]")
	  	private WebElement FirstSearchOption;
	  	
	  	//CMMS Dev: Second option in search bar
	  	@FindBy(xpath="//*[@id=\"uxgridsummaryview-1816\"]/div[2]")
	  	private WebElement SecondSearchOption;
	  	
		
		
		
		
		
//----- METHODS ------------------------------------------------------------------------------------------//
//-- This is where you define the specific methods (actions) that you want to do to the webpage. ---------//
//-- Ideally you want to section them to what type of method it is and in alphabetical order -------------//
//-- so you can find them easily. Below is an example on how to define a method. -------------------------//
//--------------------------------------------------------------------------------------------------------//
// Put a comment here about what the action is to what page objects                                       //
// public void nameOfActionHere() {                                                                       //
//     try {                                                                                              //
//	        nameOfPageObjectYouWant.click() or .sendKeys(wordYouWantToEnter)                              //
//	  	    refreshTimestamp();   (used to get the current time)                                          //
//	  	    Reporter.log("This should be the "Expected" result of the action being done", true);          //
//  	    Reporter.log("This should be the "Actual" result of the action being done", true);            //
//  	    Reporter.log(timestamp, true);    (timestamps the action to the current time)                 //
//     } catch (Exception e) {                                                                            //
//          e.printStackTrace();    (will output the error if an error occurs)                            //
//          refreshTimestamp();                                                                           //
//	  	    Reporter.log("This should be the "Expected" result of the action being done", true);          //
//		    Reporter.log("Step failed.", true);                                                           //
//		    Reporter.log(timestamp, true);                                                                //
//          throw new stepFailure("Step failed."); (stops the test and marks as failure)                  //
//     }                                                                                                  //
// }                                                                                                      //
//--------------------------------------------------------------------------------------------------------// 
	  	
	  	
//****** Commonly used methods ******//		
	  	
	  	
	  	private static void refreshTimestamp() {
	        // Update the timestamp with the current date and time
	        timestamp = new SimpleDateFormat("dd-MMM-yy HH:mm:ss").format(new Date());
	    }
	  	
	  	public void takeScreenshotWithTaskbar() {
	  	    try {
	  	        // Create a Robot object to capture the screen pixels
	  	        Robot robot = new Robot();

	  	        // Determine the size of the screen
	  	        Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());

	  	        // Capture the screen shot of the entire screen
	  	        BufferedImage screenFullImage = robot.createScreenCapture(screenRect);
	  	        
	  	        // Generate a unique file name based on the current timestamp
	  	        String fileName = "screenshot_" + getTimestamp() + ".jpg";

	  	        File destination = new File("C:\\Users\\LBX Admin\\Automated Testing Screenshots\\" + fileName);

	  	        // Save the screenshot to the specified location
	  	        ImageIO.write(screenFullImage, "jpg", destination);
	  	        
	  	        System.out.println("Screenshot captured: " + destination.getAbsolutePath());
	  	        refreshTimestamp();

	  	        // Convert the screenshot to Base64 encoded string
	  	        String base64Screenshot = convertToBase64(destination);

	  	        // Embed the screenshot image into the TestNG report using <img> tag with Base64 data
	  	        String imgTag = "<img src=\"data:image/jpeg;base64," + base64Screenshot + "\" alt=\"Screenshot\" height=\"250\" />";
	  	        Reporter.log("Take a screenshot.", true);
	  	        Reporter.log("Screenshot captured: </br>" + imgTag, true);
	  	        Reporter.log(timestamp, true);

	  	        // adding the img to an array to be called on later
	  	        imgTags.add(imgTag);
	  	        
	  	    } catch (Exception ex) {
	  	        ex.printStackTrace();
	  	        
	  	        Reporter.log("Take a screenshot.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	    }
	  	}


	    private String convertToBase64(File file) throws IOException {
	        byte[] fileContent = Files.readAllBytes(file.toPath());
	        return Base64.getEncoder().encodeToString(fileContent);
	    }
	

		private String getTimestamp() {
		    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
		    return sdf.format(new Date());
		}
		
	  	public ArrayList<String> imgTags = new ArrayList<>();

	    // Getter method to access the imgTags ArrayList
	    public ArrayList<String> getImgTags() {
	        return imgTags;
	    }
	  	
	  	
	  	
//****** CMMS Dev website section ******//	
		
		
	//---------- LOGIN ----------//
		
		//Biogen enter username and password and login to dev CMMS
		public void Login_To_CMMS_Dev(WebDriver driver, String username, String password) throws InterruptedException 
		{
			
			EnterUsername(username); 	

			EnterPassword(password); 	
			
			btn_LOGIN.click(); 	
			

			//watch this video, figure out how to reference driver in this method
			//https://www.youtube.com/watch?v=evRGeTo8TME
			
			//Close the browser
			//driver.quit();
	
		}
	  	
	//---------- CLICK ----------//

		//CMMS - login button clicking
		public void ClickLoginButton() {
			try {
				btn_LOGIN.click();
				refreshTimestamp();
				Reporter.log("Click CMMS Dev login button. " ,true);
				Reporter.log("Login button clicked. " ,true);
				Reporter.log(timestamp ,true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
				Reporter.log("Click CMMS Dev login button. " ,true);
				Reporter.log("Step failed. " ,true);
				Reporter.log(timestamp ,true);
				
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
		

		
	//---------- SENDKEYS ----------//
	  	
		//CMMS - send the password to the field
		public void EnterPassword(String password) {
			try {
				PasswordField.sendKeys(password);
				refreshTimestamp();
				Reporter.log("Entered Password. ", true);
	  	        Reporter.log("Password entered successfully. ", true);
	  	        Reporter.log(timestamp, true);
			} catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
				Reporter.log("Entered Password. ", true);
	  	        Reporter.log("Step failed. ", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
		}
		
		//CMMS - send the user name to the field
	  	public void EnterUsername(String username) {
	  	    try {
	  	        UserField.sendKeys(username);
	  	        refreshTimestamp();
	  	        Reporter.log("Entered Username. ", true);
	  	        Reporter.log("Username entered successfully. ", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Entered Username. ", true);
	  	        Reporter.log("Step failed. ", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
		//Dynamics: Click sign in button
	  	public void DynSignIn() {
	  	    try {
	  	    	DynSignInButton.click();
	  	        refreshTimestamp();
	  	        Reporter.log("Click 'Sign In' button.", true);
	  	        Reporter.log("Sign in button clicked successfully.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Click 'Sign In' button.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
		//Dynamics: Click Items button
	  	public void DynItems() {
	  	    try {
	  	    	DynItemsButton.click();
	  	        refreshTimestamp();
	  	        Reporter.log("Click 'Items' tab.", true);
	  	        Reporter.log("Items tab clicked successfully.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Click 'Items' tab.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
		//Dynamics: Click New Items button
	  	public void DynNewItems() {
	  	    try {
	  	    	DynNewButtonOnItems.click();
	  	        refreshTimestamp();
	  	        Reporter.log("Click new record.", true);
	  	        Reporter.log("Clicked new record button.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Click new record.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
		//Dynamics: Fill out required fields on Items new record page
	  	public void DynNewItemsFillOut() {
	  	    try {
	  	    	DynDescOnItems.sendKeys("Test Item 01");
	  	    	driver.switchTo().activeElement();
	  	    	Thread.sleep(2000);
	  	    	DynBaseUnitOnItems.click();
	  	    	DynBaseUnitGROnItems.click();
	  	    	Thread.sleep(2000);
	  	    	DynCostsTabOnItems.click();
	  	    	DynGPostGroupOnItems.sendKeys("SERVICES");
	  	    	Thread.sleep(2000);
	  	    	DynIPostGroupOnItems.sendKeys("FINISHED");
	  	    	//Thread.sleep(2000);
	  	        refreshTimestamp();
	  	        Reporter.log("Fill out required fields on new record form for Items.", true);
	  	        Reporter.log("Filled out all required fields on new record form for Items.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Create new record and fill out required fields for Items.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
		//Dynamics: Navigate to Vendors page
	  	public void DynVendors() {
	  	    try {
	  	    	DynBackOnItems.click();
	  	    	Thread.sleep(2000);
	  	    	DynPurchasing.click();
	  	    	Thread.sleep(2000);
	  	    	DynVendors.click();
	  	        refreshTimestamp();
	  	        Reporter.log("Go to Vendors page.", true);
	  	        Reporter.log("Navigates to Vendors page successfully.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Go to Vendors page.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
		//Dynamics: Click New Vendors button
	  	public void DynNewVendors() {
	  	    try {
	  	    	DynNewButtonOnVendors.click();
	  	        refreshTimestamp();
	  	        Reporter.log("Click new record.", true);
	  	        Reporter.log("Clicked new record button.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Click new record.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
		//Dynamics: Fill out required fields on Vendors new record page
	  	public void DynNewVendorsFillOut() {
	  	    try {
	  	    	DynNameOnVendors.sendKeys("Test Vendor 01");
	  	    	driver.switchTo().activeElement();
	  	    	Thread.sleep(2000);
	  	    	DynInvoiceTabOnVendors.click();
	  	    	Thread.sleep(2000);
	  	    	DynTaxAreaOnVendors.click();
	  	    	Thread.sleep(2000);
	  	    	DynTaxArea377OnVendors.click();
	  	    	Thread.sleep(2000);
	  	    	DynGenBusPostOnVendors.sendKeys("DOMESTIC");
	  	    	Thread.sleep(2000);
	  	    	DynVendorPostOnVendors.sendKeys("DOMESTIC");
	  	    	//Thread.sleep(2000);
	  	        refreshTimestamp();
	  	        Reporter.log("Fill out required fields on new record form for Vendors.", true);
	  	        Reporter.log("Filled out all required fields on new record form for Vendors.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Create new record and fill out required fields for Vendors.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}

	  //Dynamics: Navigate to Purchase Orders page
	  	public void DynPurchaseOrders() {
	  	    try {
	  	    	DynBackOnVendors.click();
	  	    	Thread.sleep(2000);
	  	    	DynPurchasing2.click();
	  	    	Thread.sleep(2000);
	  	    	DynPO.click();
	  	        refreshTimestamp();
	  	        Reporter.log("Go to Purchase Orders page.", true);
	  	        Reporter.log("Navigates to Purchase Orders page successfully.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Go to Purchase Orders page.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
		//Dynamics: Click New Purchase Orders button
	  	public void DynNewPurchaseOrders() {
	  	    try {
	  	    	DynNewOnPO.click();
	  	        refreshTimestamp();
	  	        Reporter.log("Click new Purchase Order record.", true);
	  	        Reporter.log("Clicked new Purchase Order record button.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Click new Purchase Order record.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
	  //Dynamics: Fill out required fields on Vendors new record page
	  	public void DynNewPurchaseOrdersFillOut() {
	  	    try {
	  	    	Thread.sleep(2000);
	  	    	DynVendorNameOnPO.sendKeys("Test Vendor 01");
	  	    	driver.switchTo().activeElement();
	  	    	Thread.sleep(2000);
	  	    	DynVendorNumOnPO.sendKeys("12345");
	  	    	Thread.sleep(2000);
	  	    	DynItemFieldOnPO.click();
	  	    	Thread.sleep(2000);
	  	    	DynItemFieldSelectionOnPO.click();
	  	    	//Thread.sleep(2000);
	  	    	//DynVendorPostOnVendors.sendKeys("DOMESTIC");
	  	    	Thread.sleep(2000);
	  	        refreshTimestamp();
	  	        Reporter.log("Fill out required fields on new record form for Vendors.", true);
	  	        Reporter.log("Filled out all required fields on new record form for Vendors.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Create new record and fill out required fields for Vendors.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
	  	
		  //Hexagon test
	  	public void HexTest() {
	  	    try {
	  	    	HexUsername.sendKeys("NRODGERS@LEANBIOLOGIX.COM");
	  	    	Thread.sleep(2000);
	  	    	HexPassword.sendKeys("Password1");
	  	    	HexLoginButton.click();
	  	    	Thread.sleep(3000);
	  	    	HexWorkTab.click();
	  	    	Thread.sleep(1000);
	  	    	HexWorkOrders.click();
	  	    	Thread.sleep(3000);
	  	    	HexStatusFilter.sendKeys("Closed");
	  	    	Thread.sleep(3000);
	  	    	HexRun.click();
	  	    	Thread.sleep(5000);
	  	        refreshTimestamp();
	  	        Reporter.log("Go to Purchase Orders page.", true);
	  	        Reporter.log("Navigates to Purchase Orders page successfully.", true);
	  	        Reporter.log(timestamp, true);
	  	    } catch (Exception e) {
	  	        // Log or report the exception details
	  	        e.printStackTrace();
	  	        
	  	        refreshTimestamp();
	  	        Reporter.log("Go to Purchase Orders page.", true);
	  	        Reporter.log("Step failed.", true);
	  	        Reporter.log(timestamp, true);
	  	        
				// Throw a custom exception to indicate the step failure
	            throw new stepFailure("Step failed.");
	  	    }
	  	}
}
